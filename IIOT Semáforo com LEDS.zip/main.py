from machine import Pin
from utime import sleep

print("Hello, ESP32!")

led_vermelho = Pin(18, Pin.OUT)
led_amarelo = Pin(5, Pin.OUT)
led_verde = Pin(15, Pin.OUT)

while True:
  led_verde.on()
  print("Led verde ligado!")
  sleep(20)
  led_verde.off()
  print("Led verde desligado!")
  sleep(0.5)

  led_amarelo.on()
  print("Led amarelo ligado!")
  sleep(10)
  led_amarelo.off()
  print("Led amarelo desligado!")
  sleep(0.5)

  led_vermelho.on()
  print("Led vermelho ligado!")
  sleep(7)
  led_vermelho.off()
  print("Led vermelho desligado!")
  sleep(0.5)
